from django.shortcuts import render
from django.http import HttpResponse
from . models import Product

# Create your views here.
def index(request):
    products = Product.objects.all()
    return render(request,'index.html',{'products':products})
    return HttpResponse ("<h1> Welcome to django </h1>")


def about(request):
    return HttpResponse ("<h1> Welcome to Jose Super Market, Rome , Italy </h1>"+ "<h2> Phone: 353444550001 </h2>")

def purchase(request):
    return HttpResponse ("<h1> Please provide your credit card details </h2>")   
       